﻿using BlazorShared.Attributes;

namespace BlazorShared.Models;

[Endpoint(Name = "catalog-brands")]
public class CatalogBrand : LookupData
{
}
